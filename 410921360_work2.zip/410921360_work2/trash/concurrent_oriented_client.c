#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define MAX_CLIENTS 10

int client_sockets[MAX_CLIENTS];
int num_clients = 0;

void *handle_client(void *arg) {
    int socket_fd = (int)arg;
    char buffer[1024];
    int read_size;

    // Handle client connection
    while ((read_size = recv(socket_fd, buffer, 1024, 0)) > 0) {
        buffer[read_size] = '\0';
        printf("Received message: %s", buffer);

        // Echo message back to client
        write(socket_fd, buffer, strlen(buffer));
    }

    // Remove client from list of active clients
    for (int i = 0; i < num_clients; i++) {
        if (client_sockets[i] == socket_fd) {
            printf("Client disconnected\n");
            for (int j = i; j < num_clients - 1; j++) {
                client_sockets[j] = client_sockets[j + 1];
            }
            num_clients--;
            break;
        }
    }

    close(socket_fd);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    int opt = 1;
    int addrlen = sizeof(server_addr);
    pthread_t thread_id;

    // Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Set socket options
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("setsockopt failed");
        exit(EXIT_FAILURE);
    }

    // Bind socket to port
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Server started on port %d\n", PORT);

    // Accept incoming connections
    while ((client_fd = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t)&addrlen)) >= 0) {
        printf("Client connected: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Add client to list of active clients
        if (num_clients < MAX_CLIENTS) {
            client_sockets[num_clients++] = client_fd;
        } else {
            printf("Too many clients, connection rejected\n");
            close(client_fd);
            continue;
        }

        // Handle client in a separate thread
        if (pthread_create(&thread_id, NULL, handle_client, (void*)&client_fd) < 0) {
            perror("pthread_create failed");
            exit(EXIT_FAILURE);
        }
    }

    if (client_fd < 0) {
        perror("accept failed");
        exit(EXIT_FAILURE);
    }

    return 0;
}
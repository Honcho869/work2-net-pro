#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SERVER_ADDR "192.168.2.213"
#define SERVER_PORT 8080
#define BUFFER_SIZE 1024

void receiver(){
    int sock_fd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    int read_size;

    // Create socket
    if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Connect to server
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(SERVER_ADDR);
    server_addr.sin_port = htons(SERVER_PORT);
    if (connect(sock_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("connect failed");
        exit(EXIT_FAILURE);
    }

    // Prompt for commands and send to server
    while (1)
    {
        printf("%% ");
        fgets(buffer, BUFFER_SIZE, stdin);
        if (send(sock_fd, buffer, strlen(buffer), 0) < 0)
        {
            perror("send failed");
            exit(EXIT_FAILURE);
        }

        // Receive response from server and display
        read_size = recv(sock_fd, buffer, BUFFER_SIZE, 0);
        if (read_size > 0)
        {
            buffer[read_size] = '\0';
            printf("%s\n", buffer);
        }
    }

    close(sock_fd);
}

int main(int argc, char *argv[])
{
    receiver();
    return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_COMMAND_LENGTH 256
#define MAX_NUM_ARGS 5000

void run_command(char **args, int in_fd, int out_fd, int num_iters)
{
    pid_t pid;
    int pipe_fd[2];

    if (pipe(pipe_fd) == -1)
    {
        perror("pipe");
        exit(1);
    }

    pid = fork();
    if (pid == 0)
    {
        // Child process
        close(pipe_fd[0]); // Close read end of the pipe

        if (in_fd != STDIN_FILENO)
        {
            dup2(in_fd, STDIN_FILENO);
            close(in_fd);
        }

        dup2(pipe_fd[1], STDOUT_FILENO); // Redirect stdout to the write end of the pipe
        close(pipe_fd[1]);               // Close write end of the pipe

        execvp(args[0], args);
        perror("execvp");
        exit(1);
    }
    else if (pid < 0)
    {
        printf("Fork failed\n");
        exit(1);
    }
    else
    {
        // Parent process
        close(pipe_fd[1]); // Close write end of the pipe
        char buffer[1024];
        int n_read;

        for (int i = 0; i < num_iters; i++) {
            while ((n_read = read(pipe_fd[0], buffer, 1024)) > 0)
            {

                for (int i = 0; i < n_read; i++)
                {
                    if (buffer[i] == '\n')
                    {
                        printf("\n");
                    }
                    else
                    {
                        printf("%c", buffer[i]);
                    }
                }
            }
            lseek(pipe_fd[0], 0, SEEK_SET);
        }

        close(pipe_fd[0]); // Close read end of the pipe
        int status;
        waitpid(pid, &status, 0);
    }
}

int main()
{
    char input[MAX_COMMAND_LENGTH];
    char *args[MAX_NUM_ARGS];
    int num_pipes = 0;

    char *bin_path = "/home/dakeza/working_dir/bin";
    char *existing_path = getenv("PATH");

    // create a new string with the bin folder path appended to the existing path
    char new_path[1024];
    sprintf(new_path, "%s:%s", bin_path, existing_path);

    // set the new path as the value of the environment variable PATH
    setenv("PATH", new_path, 1);

    while (1)
    {
        printf("%% ");
        fgets(input, MAX_COMMAND_LENGTH, stdin);
        input[strlen(input) - 1] = '\0';

        // check for pipes
        char *pipe_token = strtok(input, "|");
        int in_fd = STDIN_FILENO;
        while (pipe_token != NULL)
        {
            // split input into tokens
            char *token = strtok(pipe_token, " ");
            int i = 0;
            while (token != NULL && i < MAX_NUM_ARGS)
            {
                args[i] = token;
                token = strtok(NULL, " ");
                i++;
            }
            args[i] = NULL;

            // check for built-in commands
            if (strcmp(args[0], "ls") == 0)
            {
                int out_fd = num_pipes > 0 ? STDOUT_FILENO : STDOUT_FILENO;
                run_command(args, in_fd, out_fd,num_pipes);
            }
            else if (strcmp(args[0], "cat") == 0)
            {
                int out_fd = num_pipes > 0 ? STDOUT_FILENO : STDOUT_FILENO;
                run_command(args, in_fd, out_fd,num_pipes);
            }
            else if (strcmp(args[0], "number") == 0)
            {
                int out_fd = num_pipes > 0 ? STDOUT_FILENO : STDOUT_FILENO;
                run_command(args, in_fd, out_fd,num_pipes);
            }
            else if (strcmp(args[0], "quit") == 0 || strcmp(args[0], "q") == 0 || strcmp(args[0], "exit") == 0)
            {
                exit(0);
            }
            else
            {
                // not a built-in command, so try to execute it as a system command
                int out_fd = num_pipes > 0 ? STDOUT_FILENO : STDOUT_FILENO;
                run_command(args, in_fd, out_fd,num_pipes);
            }

            in_fd = STDIN_FILENO;
            num_pipes++;
            pipe_token = strtok(NULL, "|");
        }

        num_pipes = 0;
    }

    return 0;
}